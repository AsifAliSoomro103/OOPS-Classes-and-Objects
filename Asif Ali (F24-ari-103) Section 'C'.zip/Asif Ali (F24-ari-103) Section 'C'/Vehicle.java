class Vehicle {
    String model;
    String brand;
    double price;
    int year;
    String fuelType;

    Vehicle(String model, String brand) {
        this.model = model;
        this.brand = brand;
        this.price = 0;
        this.year = 2024;
        this.fuelType = "Petrol";
    }

    Vehicle(String model, String brand, double price) {
        this.model = model;
        this.brand = brand;
        this.price = price;
        this.year = 2024;
        this.fuelType = "Petrol";
    }

    Vehicle(String model, String brand, double price, int year) {
        this.model = model;
        this.brand = brand;
        this.price = price;
        this.year = year;
        this.fuelType = "Petrol";
    }

    Vehicle(String model, String brand, double price, int year, String fuelType) {
        this.model = model;
        this.brand = brand;
        this.price = price;
        this.year = year;
        this.fuelType = fuelType;
    }
    void displayInfo() {
        System.out.println("Model " + model);
        System.out.println("Brand " + brand);
        System.out.println("Price " + price);
        System.out.println("Year " + year);
        System.out.println("Fuel Type " + fuelType);
    }

    public static void main(String[] args) {
        Vehicle v1 = new Vehicle("Civic", "Honda");
        Vehicle v2 = new Vehicle("Corolla", "Toyota", 250000);
        Vehicle v3 = new Vehicle("Model S", "Tesla", 79999, 2021);
        Vehicle v4 = new Vehicle("Mustang", "Ford", 550000, 2022, "Electric");
        v1.displayInfo();
        v2.displayInfo();
        v3.displayInfo();
        v4.displayInfo();
    }


}